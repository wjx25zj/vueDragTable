import TableCom from './views/TableCom.vue';
import { DragTable } from './DragTable';
export {
    TableCom,
    DragTable,
}


