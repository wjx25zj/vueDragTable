export class UtilsConfig {
    public static keepReg: RegExp = /\$|userData/;
}