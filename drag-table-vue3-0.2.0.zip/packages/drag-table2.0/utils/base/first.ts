export function first(array: any[]) {
    return array ? array[0] : undefined;
}