export interface TablerRowDataInterface {
    
}