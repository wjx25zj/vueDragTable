import { IndexContainerInterface } from "../container/IndexContainer";

export interface IndexTheadInterface extends IndexContainerInterface {

}