import { TheadContainerInterface } from "../container/TheadContainer";

export interface BaseTheadInterface extends TheadContainerInterface{
    dragStartData?: any ;
}