export interface PositionInterface {
    table?: any;
    colStr?: any;
    colNum?: number;
    rowStr?: any;
    rowNum?: number;
}
